Group Member 1:
Jason Nowotny
5344801
nowot005

Group Member 2:
Henry Sotsaikich
5495759
sotsa001
